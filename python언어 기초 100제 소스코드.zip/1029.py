a = input()
n = int(a, 16)
print('%o' % n)
