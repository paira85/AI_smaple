a, d, n = input().split()

a = int(a)
d = int(d)
n = int(n)

for i in range(1, n) :
  a = a+d

print(a)
