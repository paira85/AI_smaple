c = input()
c = ord(c)
print(chr(c+1))
