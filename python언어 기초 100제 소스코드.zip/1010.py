c = input()
print(c)
