w, n = input().split()
print(w*int(n))
