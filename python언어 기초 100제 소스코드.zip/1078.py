c = 'a'
while c!='q':
  c = input()
  print(c)
