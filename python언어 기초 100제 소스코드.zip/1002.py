print("Hello World")
