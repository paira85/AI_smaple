a, b = input().split()
print(b, a)
