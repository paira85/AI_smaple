print('print("Hello World")')
