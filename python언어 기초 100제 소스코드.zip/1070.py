n = int(input())

if n//3==1 :
  print("spring")
elif n//3==2 :
  print("summer")
elif n//3==3 :
  print("fall")
else :
  print("winter")
