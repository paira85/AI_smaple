f1, f2 = input().split()
f3 = float(f1)**float(f2)
print(f3)
