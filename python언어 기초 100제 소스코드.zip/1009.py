n = input()
print(n)
