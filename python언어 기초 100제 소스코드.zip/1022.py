s = input()
print(s[0:2], s[2:4], s[4:6], sep=' ')
