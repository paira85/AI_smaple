f = input()
print(f)
