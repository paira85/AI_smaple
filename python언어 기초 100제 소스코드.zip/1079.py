n = int(input())

s = 0
t = 0
while s<n :
  t = t+1
  s = s+t
  
print(t)
