print('"Hello World"')
