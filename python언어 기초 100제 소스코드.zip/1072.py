n = int(input())

while n!=0 :
  print(n)
  n = n-1
