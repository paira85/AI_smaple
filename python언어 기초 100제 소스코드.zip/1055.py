a, b = input().split()
print(bool(int(a)) or bool(int(b)))
