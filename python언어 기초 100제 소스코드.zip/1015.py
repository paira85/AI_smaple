a, b = input().split()
print(a)
print(b)
