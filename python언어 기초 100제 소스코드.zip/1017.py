s = input()
print(s, s, s)
