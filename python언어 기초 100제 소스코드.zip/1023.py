h, m, s = input().split(':')
print(m)
