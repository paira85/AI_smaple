f1 = input()
f2 = input()
f3 = float(f1) + float(f2)
print(f3)
