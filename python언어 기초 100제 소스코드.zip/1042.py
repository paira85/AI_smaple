f = float(input())
print(round(f, 2))
