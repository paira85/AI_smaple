f1, f2 = input().split()
m = float(f1)*float(f2)
print(m)
