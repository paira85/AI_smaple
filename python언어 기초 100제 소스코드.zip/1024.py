w1, w2 = input().split()
s = w1 + w2
print(s)
