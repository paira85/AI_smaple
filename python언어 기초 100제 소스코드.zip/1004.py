print("'Hello'")
