a = bool(int(input()))
print(not a)
