n = int(input())

t = 0
while t<=n :
  print(t)
  t += 1
