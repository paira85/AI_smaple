a, b, c = input().split()

a = int(a)
b = int(b)
c = int(c)

if a%2==0 :
  print("even")
else :
  print("odd")

if b%2==0 :
  print("even")
else :
  print("odd")

if c%2==0 :
  print("even")
else :
  print("odd")
