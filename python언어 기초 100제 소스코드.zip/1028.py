a = input()
n = int(a)
print('%X'% n)
