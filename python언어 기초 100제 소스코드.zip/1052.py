n = int(input())
print(bool(n))
