c = int(input())
print(chr(c))
