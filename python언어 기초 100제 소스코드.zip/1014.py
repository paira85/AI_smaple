f = input() 
print(f)
print(f)
print(f)
