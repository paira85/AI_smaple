n = input()
s = input()
print(int(n)*s)
