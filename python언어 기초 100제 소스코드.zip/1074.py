c = ord(input())
t = ord('a')
while t<=c :
  print(chr(t), end=' ')
  t += 1
