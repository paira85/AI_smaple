a = input() 
b = input()
print(a)
print(b)
