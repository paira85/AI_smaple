f1, f2 = input().split()
print(round(float(f1)/float(f2), 3))
