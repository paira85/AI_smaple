a, b = input().split()
c = int(a)-int(b)
print(c)
