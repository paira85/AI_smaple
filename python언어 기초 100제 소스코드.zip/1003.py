print("Hello")
print("World")
